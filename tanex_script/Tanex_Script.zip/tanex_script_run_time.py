# Tanex Script 运行时执行器
# 完整的运行时环境，支持 AST 解释执行、变量存储、错误处理、警告系统、输出功能等

import json
import os
from typing import Any, Dict, Optional
from define import *

# Tanex Script 运行时执行器异常类
class run_time_error(tanex_script_error):
    # 运行时错误异常类
    pass

# 类型定义
ast = Dict[str, Any]

# Tanex Script 运行时执行器主类
class tanex_script_run_time:
    def __init__(self, path: str):
        # 初始化运行时环境，加载AST并设置变量存储
        path = os.path.splitext(path)[0] + '.tscc'
        if not os.path.exists(path):
            error([f'编译文件 {path} 不存在'])
        try:
            with open(path, 'r', encoding='utf-8') as file:
                data = json.load(file)
        except Exception:
            exit(1)
        # AST 存放在顶层键 'Tanex Script'
        self.ast = data.get('Tanex Script', [])
        # 作用域栈，最后一项是当前作用域（dict）
        self.scopes: list[Dict[str, Any]] = [{}]

    def get_value(self, name: str) -> ast:
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        return {'none_type': {'value': 'none'}}

    def _get_key(self, dict: ast) -> str:
        return list(dict.keys())[0]

    def _coerce_value(self, node: Any) -> Any:
        if isinstance(node, dict):
            key = self._get_key(node)
            if key in ('number', 'integer'):
                value = node[key].get('value')
                if isinstance(value, str):
                    stripped = value.strip()
                    if len(stripped) >= 2 and stripped[0] == stripped[-1] and stripped[0] in ('"', "'"):
                        stripped = stripped[1:-1]
                    if stripped.startswith("'") and stripped.endswith("'"):
                        stripped = stripped[1:-1]
                    try:
                        return int(stripped)
                    except ValueError:
                        try:
                            return float(stripped)
                        except ValueError:
                            return stripped
                return value
            if key == 'string':
                value = node[key].get('value')
                if isinstance(value, str):
                    stripped = value.strip()
                    if len(stripped) >= 2 and stripped[0] == stripped[-1] and stripped[0] in ('"', "'"):
                        return stripped[1:-1]
                    return stripped
                return value
            if key == 'boolean':
                value = node[key].get('value')
                return str(value).lower() == 'true'
            if key in ('none_type', 'nan_type', 'infinite_type'):
                return None
            if key == 'address':
                return node[key].get('value')
            if key == 'name':
                return node[key].get('value')
        return node

    def _coerce_numeric(self, node: Any) -> float:
        value = self._coerce_value(node)
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            stripped = value.strip()
            if len(stripped) >= 2 and stripped[0] == stripped[-1] and stripped[0] in ('"', "'"):
                stripped = stripped[1:-1]
            try:
                return float(stripped)
            except ValueError:
                self.error('数值转换失败')
        self.error('数值转换失败')

    def resolve_name_identifier(self, name_ast: ast) -> Optional[str]:
        if not isinstance(name_ast, dict):
            return None
        key = self._get_key(name_ast)
        if key == 'name':
            return self.resolve_name_identifier(name_ast['name'])
        if key == 'value':
            return name_ast['value'] if isinstance(name_ast['value'], str) else None
        return None

    def statement(self, code_ast: ast) -> ast:
        if self._get_key(code_ast) != 'unary':
            return {'none_type': {'value': 'none'}}
        unary = code_ast['unary'].get('operator')
        operand_ast = code_ast['unary'].get('operand')
        if unary in ('*', '**', '***'):
            node = operand_ast
            if isinstance(node, dict):
                if self._get_key(node) == 'name':
                    name = node['name']['value']
                elif self._get_key(node) == 'value' and isinstance(node.get('value'), str):
                    name = node['value']
                else:
                    name = None
            else:
                name = None
            if not isinstance(name, str) or not name:
                return {'none_type': {'value': 'none'}}
            self.scopes[-1][name] = {'none_type': {'value': 'none'}}
            return {'name': {'value': name}}
        operand = self.run_code(operand_ast) if operand_ast is not None else {'none_type': {'value': 'none'}}
        if unary == '+':
            return operand
        if unary == '-':
            try:
                value = -self._coerce_numeric(operand)
                return {'number': {'value': str(value)}}
            except run_time_error:
                raise
            except Exception:
                self.error('数值转换失败')
        if unary == '!':
            truthy = False
            if isinstance(operand, dict):
                truthy = bool(operand)
            return {'boolean': {'value': str(not truthy).lower()}}
        if unary == '~':
            try:
                value = ~int(self._coerce_numeric(operand))
                return {'integer': {'value': str(value)}}
            except run_time_error:
                raise
            except Exception:
                self.error('数值转换失败')
        return {'none_type': {'value': 'none'}}

    def calculate(self, code_ast: ast) -> ast:
        if self._get_key(code_ast) == 'binary':
            binary = code_ast['binary']
            if not isinstance(binary, list) or len(binary) < 3:
                return {'none_type': {'value': 'none'}}
            op, left_ast, right_ast = binary[0], binary[1], binary[2]
            left = self.run_code(left_ast)
            right = self.run_code(right_ast)
            left_value = self._coerce_value(left)
            right_value = self._coerce_value(right)
            if isinstance(left_value, (int, float)) and isinstance(right_value, (int, float)):
                a = float(left_value)
                b = float(right_value)
                if op == '+':
                    return {'number': {'value': str(a + b)}}
                if op == '-':
                    return {'number': {'value': str(a - b)}}
                if op == '*':
                    return {'number': {'value': str(a * b)}}
                if op == '/':
                    return {'number': {'value': str(a / b)}}
                if op == '%':
                    return {'number': {'value': str(a % b)}}
                if op == '^':
                    return {'number': {'value': str(a ** b)}}
                if op == '==':
                    return {'boolean': {'value': str(a == b).lower()}}
                if op == '<':
                    return {'boolean': {'value': str(a < b).lower()}}
                if op == '<=':
                    return {'boolean': {'value': str(a <= b).lower()}}
                if op == '>':
                    return {'boolean': {'value': str(a > b).lower()}}
                if op == '>=':
                    return {'boolean': {'value': str(a >= b).lower()}}
            if op == '+' and isinstance(left_value, str) and isinstance(right_value, str):
                return {'string': {'value': f'"{left_value + right_value}"'}}
            return {'none_type': {'value': 'none'}}
        return {'none_type': {'value': 'none'}}

    def assignment(self, code_ast: ast) -> ast:
        left_ast = code_ast['assignment']['left']
        if self._get_key(left_ast) == 'unary':
            left_name = self.statement(left_ast)['name']['value']
        else:
            if self._get_key(left_ast) == 'name':
                left_name = left_ast['name']['value']
            else:
                self.error('赋值左侧必须是名称')
        value = self.run_code(code_ast['assignment']['right'])
        op = code_ast['assignment']['operator']
        if op == '=':
            self.scopes[-1][left_name] = value
            return value
        existing = self.get_value(left_name)
        if op in ('+=', '-=', '*=', '/=', '%=', '^=', '&=', '|='):
            left_value = self._coerce_value(existing)
            right_value = self._coerce_value(value)
            if isinstance(left_value, (int, float)) and isinstance(right_value, (int, float)):
                a = float(left_value)
                b = float(right_value)
                if op == '+=':
                    result = a + b
                elif op == '-=':
                    result = a - b
                elif op == '*=':
                    result = a * b
                elif op == '/=':
                    result = a / b
                elif op == '%=':
                    result = a % b
                elif op == '^=':
                    result = a ** b
                elif op == '&=':
                    result = int(a) & int(b)
                elif op == '|=':
                    result = int(a) | int(b)
                else:
                    result = a
                self.scopes[-1][left_name] = {'number': {'value': str(result)}}
                return self.scopes[-1][left_name]
            if op == '+=' and isinstance(left_value, str) and isinstance(right_value, str):
                result = left_value + right_value
                self.scopes[-1][left_name] = {'string': {'value': f'"{result}"'}}
                return self.scopes[-1][left_name]
            if op == '+=' and left_value is None:
                self.scopes[-1][left_name] = value
                return self.scopes[-1][left_name]
        self.error(f'暂不支持赋值运算符 {op}')
        return {'none_type': {'value': 'none'}}

    def error(self, message: str):
        raise run_time_error(message)

    def call_function(self, code_ast: ast) -> ast:
        name_ast = code_ast['function']['name']
        args_ast = code_ast['function'].get('arg', [])
        func_name = self.resolve_name_identifier(name_ast)
        if func_name is None:
            name_value = self.run_code(name_ast) if isinstance(name_ast, dict) else name_ast
            if isinstance(name_value, dict) and 'name' in name_value:
                func_name = self.resolve_name_identifier(name_value['name'])
            elif isinstance(name_value, str):
                func_name = name_value
        args = []
        if isinstance(args_ast, list):
            args = [self.run_code(arg) for arg in args_ast]
        elif args_ast:
            args = [self.run_code(args_ast)]
        if func_name == 'output':
            if args:
                arg = args[0]
                if isinstance(arg, dict) and 'string' in arg:
                    tanex_script_output(arg['string']['value'])
            return {'none_type': {'value': 'none'}}
        # 目前未知函数不抛错，直接返回 none
        return {'none_type': {'value': 'none'}}

    def evaluate_list(self, code_ast: ast) -> ast:
        items = code_ast['list']['items']
        evaluated = [self.run_code(item) for item in items]
        return {'list': {'items': evaluated}}

    def evaluate_subscript(self, code_ast: ast) -> ast:
        left = self.run_code(code_ast['subscript']['left'])
        right = self.run_code(code_ast['subscript']['right'])
        if isinstance(left, dict) and 'list' in left and isinstance(right, dict) and 'integer' in right:
            idx = int(right['integer']['value'])
            items = left['list']['items']
            if 0 <= idx < len(items):
                return items[idx]
        return {'none_type': {'value': 'none'}}

    def evaluate_member(self, code_ast: ast) -> ast:
        left = self.run_code(code_ast['member']['left'])
        right = code_ast['member']['right']
        if isinstance(left, dict) and 'list' in left and self._get_key(right) == 'name':
            key = right['name']['value']
            if key == 'length':
                return {'integer': {'value': str(len(left['list']['items']))}}
        return {'none_type': {'value': 'none'}}

    def evaluate_code_block(self, code_ast: ast) -> ast:
        block = code_ast['code']['statements']
        self.scopes.append({})
        last = {'none_type': {'value': 'none'}}
        for stmt in block:
            last = self.run_code(stmt)
        self.scopes.pop()
        return last

    def evaluate_ternary(self, code_ast: ast) -> ast:
        cond = self.run_code(code_ast['ternary']['condition'])
        if isinstance(cond, dict) and 'boolean' in cond:
            cond_value = cond['boolean']['value'] == 'true'
            branch = code_ast['ternary']['true_branch'] if cond_value else code_ast['ternary']['false_branch']
            return self.run_code(branch)
        return self.run_code(code_ast['ternary']['false_branch'])

    def run(self):
        last = {'none_type': {'value': 'none'}}
        for stmt in self.ast:
            last = self.run_code(stmt)
        return last

    def run_code(self, code_ast: ast) -> ast:
        key = self._get_key(code_ast)
        if key == 'assignment':
            return self.assignment(code_ast)
        if key in ('number', 'string', 'integer', 'address'):
            return code_ast
        if key in ('boolean', 'none_type', 'nan_type', 'infinite_type'):
            return code_ast
        if key == 'name':
            return self.get_value(code_ast['name']['value'])
        if key == 'binary':
            return self.calculate(code_ast)
        if key == 'function':
            return self.call_function(code_ast)
        if key == 'list':
            return self.evaluate_list(code_ast)
        if key == 'subscript':
            return self.evaluate_subscript(code_ast)
        if key == 'member':
            return self.evaluate_member(code_ast)
        if key == 'code':
            return self.evaluate_code_block(code_ast)
        if key == 'ternary':
            return self.evaluate_ternary(code_ast)
        if key == 'unary':
            return self.statement(code_ast)
        return {'none_type': {'value': 'none'}}

def run_code(path: str):
    try:
        run_time = tanex_script_run_time(path)
        run_time.run()
    except tanex_script_error as e:
        error(['运行失败', [str(e)]])

# 导出函数
__all__ = ['run_code']
