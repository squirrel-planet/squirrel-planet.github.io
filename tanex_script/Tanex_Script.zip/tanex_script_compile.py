from define import *
import os
import json
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
import unicodedata

# Tanex Script 解释器 - 用于解析和执行 Tanex Script 语言
# 主要功能：词法分析、语法分析、AST 生成

ast = Any

@dataclass
class Token:
    text: str
    line: int
    col: int


def _convert_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _convert_value(v) for k, v in value.items()}
    if isinstance(value, list) or isinstance(value, tuple):
        return [_convert_value(item) for item in value]
    if isinstance(value, (str, int, float)) or value is None:
        return value
    if hasattr(value, 'to_dict'):
        return value.to_dict()
    return value

def node(type: str, payload: Any) -> Dict[str, Any]:
    return {type: _convert_value(payload)}

class syntax_error(tanex_script_error):
    pass

class parse_error(tanex_script_error):
    pass

class lexer:
    operator_tokens = [
        '***', '**', '->', '<-', '=>', '$$', '&&', '||', '==', '!=', '<=', '>=',
        '<<', '>>', '+=', '-=', '*=', '/=', '%=', '^=', '&=', '|=', '\\=',
            '+', '-', '*', '/', '%', '^', '<', '>', '!', '~', '$', '@', '=', ',', ';', '\\', '?',
        '[', ']', '{', '}', '(', ')', '.', ':', '|', '$$$'
    ]

    def parse_to_tokens(self, code: str) -> List[Token]:
        tokens: List[Token] = []
        position = 0
        length = len(code)
        line = 1
        col = 0
        def current_position() -> tuple[int, int]:
            return (line, col + 1)

        def consume_char() -> str:
            nonlocal position, line, col
            ch = code[position]
            position += 1
            if ch == '\n':
                line += 1
                col = 0
            else:
                col += 1
            return ch
        while position < length:
            char = code[position]
            if char.isspace():
                consume_char()
                continue
            if char == '#':
                token_line = line
                token_col = col + 1
                consume_char()
                start = position
                while position < length and code[position] != '#':
                    consume_char()
                if position >= length:
                    raise syntax_error('注释未闭合', token_line, token_col, '#' + code[start:position])
                content = code[start:position]
                consume_char()
                tokens.append(Token(f'#{content}#', token_line, token_col))
                continue
            if char in ('"', "'"):
                quote = char
                token_line = line
                token_col = col + 1
                start = position
                start_line, start_col = current_position()
                consume_char()
                escaped = False
                while position < length:
                    current = code[position]
                    if escaped:
                        escaped = False
                        consume_char()
                        continue
                    if current == '\\':
                        escaped = True
                        consume_char()
                        continue
                    consume_char()
                    if current == quote:
                        break
                else:
                    raise syntax_error(f'字符串未闭合: {code[start:]}', start_line, start_col, code[start:position])
                text = code[start:position]
                tokens.append(Token(text, token_line, token_col))
                continue
            if char == '`':
                token_line = line
                token_col = col + 1
                start = position
                start_line, start_col = current_position()
                consume_char()
                while position < length and code[position] != '`':
                    consume_char()
                if position >= length or code[position] != '`':
                    raise syntax_error('地址字面量未闭合', start_line, start_col, code[start:position])
                consume_char()
                tokens.append(Token(code[start:position], token_line, token_col))
                continue
            if char.isdigit():
                token_line = line
                token_col = col + 1
                start = position
                while position < length and code[position].isdigit():
                    consume_char()
                tokens.append(Token(code[start:position], token_line, token_col))
                continue

            # 支持更广泛的 Unicode 字符作为标识符（包含字母与记号）
            def _is_ident_start(ch: str) -> bool:
                if ch == '_':
                    return True
                cat = unicodedata.category(ch)
                return cat[0] in ('L', 'M')

            def _is_ident_part(ch: str) -> bool:
                if ch == '_':
                    return True
                cat = unicodedata.category(ch)
                return cat[0] in ('L', 'M')

            if _is_ident_start(char):
                token_line = line
                token_col = col + 1
                start = position
                while position < length and _is_ident_part(code[position]):
                    consume_char()
                ident = code[start:position]
                kw_map = {
                    'and': '&&',
                    'or': '||',
                    'not': '!',
                    'is': '=='
                }
                tokens.append(Token(kw_map.get(ident, ident), token_line, token_col))
                continue
            matched = False
            for op in self.operator_tokens:
                if code.startswith(op, position):
                    token_line = line
                    token_col = col + 1
                    for _ in range(len(op)):
                        consume_char()
                    tokens.append(Token(op, token_line, token_col))
                    matched = True
                    break
            if matched:
                continue
            line_num, col_num = current_position()
            raise syntax_error(f'无法识别字符: {char}', line_num, col_num, char)
        return tokens

class parser:
    BINARY_PRECEDENCE = {
        '=': 1, '+=': 1, '-=': 1, '*=': 1, '/=': 1, '%=': 1, '^=': 1, '&=': 1, '|=': 1, '\\=': 1,
        '||': 2,
        '&&': 3,
        '?': 4,
        '|': 4,
        '==': 4, '!=': 4,
        '<': 5, '<=': 5, '>': 5, '>=': 5, 'in': 5,
        '+': 6, '-': 6,
        '*': 7, '/': 7, '\\': 7, '%': 7, '^': 7, '<<': 7, '>>': 7, '$$': 7,
        '=>': 1,
    }

    UNARY_TOKENS = {'+', '-', '!', '~', '*', '/', '**', '***', '$', '@', '->', '<-', 'return'}

    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.index = 0

    def current(self) -> Optional[Token]:
        if self.index < len(self.tokens):
            return self.tokens[self.index]
        return None

    def raise_error(self, message: str, token: Optional[Token] = None):
        if token is None:
            token = self.current()
        if token is None:
            raise parse_error(message)
        raise parse_error(message, token.line, token.col, token.text)

    def advance(self) -> Optional[Token]:
        token = self.current()
        self.index += 1
        return token

    def expect(self, expected: str) -> Token:
        token = self.current()
        if token is None:
            self.raise_error(f'期望 {expected} ，但收到意外结束')
        if token.text != expected:
            self.raise_error(f'期望 {expected} ，但收到 {token.text}', token)
        self.advance()
        return token

    def match(self, *options: str) -> bool:
        token = self.current()
        if token is None:
            return False
        if token.text in options:
            self.advance()
            return True
        return False

    def _position(self, token: Token) -> List[int]:
        return [token.line, token.col]

    def to_json(self) -> List[Dict[str, Any]]:
        statements: List[Dict[str, Any]] = []
        while True:
            current = self.current()
            if current is None:
                break
            if current.text == ';':
                self.advance()
                continue
            expr = self.parse_statement()
            if isinstance(expr, dict) and 'comment' in expr:
                continue
            statements.append(expr)
        return statements

    def parse_statement(self) -> ast:
        expr = self.parse_expression()
        current = self.current()
        if current is None or current.text != ';':
            self.raise_error('语句必须以分号结束', current)
        self.advance()
        return expr

    def parse_expression(self, precedence: int = 0) -> ast:
        token = self.current()
        if token is None:
            self.raise_error('意外结束')

        left = self.parse_prefix()

        while True:
            token = self.current()
            if token is None:
                break
            if token.text in ('[', '(', '.', '{'):
                left = self.parse_suffix(left)
                continue
            if token.text == '?':
                if self.BINARY_PRECEDENCE.get(token.text, 0) <= precedence:
                    break
                left = self.parse_ternary(left)
                continue
            if token.text == '|':
                if self.BINARY_PRECEDENCE.get(token.text, 0) <= precedence:
                    break
                left = self.parse_try(left)
                continue
            op_prec = self.get_precedence(token.text)
            if op_prec is None or op_prec <= precedence:
                break
            op_token = self.advance()
            assert op_token is not None
            op = op_token.text
            if op in ('=', '+=', '-=', '*=', '/=', '%=', '^=', '&=', '|=', '\\='):
                right = self.parse_expression(0)
                left = {
                    'assignment': {
                        'operator': op,
                        'left': left,
                        'right': right,
                        'pos': self._position(op_token)
                    }
                }
            else:
                right = self.parse_expression(op_prec)
                left = {
                    'binary': [op, left, right, self._position(op_token)]
                }
        return left

    def parse_prefix(self) -> ast:
        token = self.current()
        if token is None:
            self.raise_error('意外结束')

        if token.text in self.UNARY_TOKENS:
            op_token = self.advance()
            assert op_token is not None
            operand = self.parse_expression(20)
            return node('unary', {'operator': op_token.text, 'operand': operand, 'pos': self._position(op_token)})

        if token.text == '(':
            self.advance()
            expr = self.parse_expression()
            self.expect(')')
            return expr

        if token.text == '[':
            return self.parse_list()

        if token.text == '{':
            return self.parse_code_block()

        self.advance()
        return self.atom(token)

    def parse_suffix(self, left: ast) -> ast:
        token = self.current()
        if token is None:
            self.raise_error('意外结束')

        # 不允许在字面量（number/string/boolean/none/nan/infinite/address）后使用后缀
        def _is_literal(node: ast) -> bool:
            if isinstance(node, dict):
                return list(node.keys())[0] in {'number', 'string', 'boolean', 'none_type', 'nan_type', 'infinite_type', 'address'}
            return False

        if _is_literal(left):
            if token.text in ('[', '(', '.', '{'):
                self.raise_error(f'语法错误：不允许对字面量使用后缀 {token.text}', token)

        if token.text == '[':
            open_token = self.advance()
            assert open_token is not None
            right = self.parse_expression()
            self.expect(']')
            return node('subscript', {'left': left, 'right': right, 'pos': self._position(open_token)})

        if token.text == '(':
            open_token = self.advance()
            assert open_token is not None
            args = []
            # 兼容空参数：连续逗号之间视为 none_type
            current = self.current()
            while current is not None and current.text != ')':
                if current.text == ',':
                    args.append(node('none_type', {'value': 'none', 'pos': self._position(current)}))
                    self.advance()
                    current = self.current()
                    continue
                args.append(self.parse_expression())
                current = self.current()
                if current is not None and current.text == ',':
                    self.advance()
                    current = self.current()
                    continue
                break
            self.expect(')')
            arg_value = args[0] if len(args) == 1 else args
            name = left
            return node('function', {'name': name, 'arg': arg_value, 'pos': self._position(open_token)})

        if token.text == '.':
            op_token = self.advance()
            assert op_token is not None
            member = self.current()
            if member is None:
                self.raise_error('成员访问缺少名称')
            self.advance()
            return node('member', {
                'left': left,
                'right': node('name', {'value': member.text, 'pos': self._position(member)}),
                'pos': self._position(op_token)
            })

        if token.text == '{':
            open_token = self.advance()
            assert open_token is not None
            items: List[ast] = []
            current = self.current()
            # 允许空项（连续逗号），用 none_type 占位
            while True:
                if current is None or current.text == '}':
                    break
                if current.text == ',':
                    items.append(node('none_type', {'value': 'none', 'pos': self._position(current)}))
                    self.advance()
                    current = self.current()
                else:
                    items.append(self.parse_expression())
                    current = self.current()
                if current is None or current.text == '}':
                    break
                if self.match(','):
                    current = self.current()
                    continue
                break
            self.expect('}')
            return node('new', {
                'type': left,
                'include': items,
                'pos': self._position(open_token)
            })

        self.raise_error(f'无法解析后缀: {token.text}', token)

    def parse_list(self) -> ast:
        open_token = self.expect('[')
        items: List[ast] = []
        current = self.current()
        while current is not None and current.text != ']':
            items.append(self.parse_expression())
            if not self.match(','):
                break
            current = self.current()
        self.expect(']')
        return node('list', {'items': items, 'pos': self._position(open_token)})

    def parse_code_block(self) -> ast:
        open_token = self.expect('{')
        statements: List[ast] = []
        current = self.current()
        while current is not None and current.text != '}':
            if current.text == ';':
                self.advance()
                current = self.current()
                continue
            statements.append(self.parse_statement())
            current = self.current()
        self.expect('}')
        return node('code', {'statements': statements, 'pos': self._position(open_token)})

    def parse_ternary(self, left: ast) -> ast:
        op_token = self.expect('?')
        true_branch = self.parse_expression()
        self.expect(':')
        false_branch = self.parse_expression()
        return node('ternary', {'operator': '?', 'condition': left, 'true_branch': true_branch, 'false_branch': false_branch, 'pos': self._position(op_token)})

    def parse_try(self, left: ast) -> ast:
        op_token = self.expect('|')
        error_arg = self.parse_expression()
        self.expect(':')
        catch_block = self.parse_expression()
        current = self.current()
        if current is not None and current.text == ':':
            self.advance()
            else_block = self.parse_expression()
        else:
            else_block = node('none_type', {'value': 'none', 'pos': self._position(op_token)})
        return node('try', {'left': left, 'error_arg': error_arg, 'catch_block': catch_block, 'else_block': else_block, 'pos': self._position(op_token)})

    def atom(self, token: Token) -> ast:
        if token.text == 'true' or token.text == 'false':
            return node('boolean', {'value': token.text, 'pos': self._position(token)})
        if token.text == 'none':
            return node('none_type', {'value': token.text, 'pos': self._position(token)})
        if token.text == 'nan':
            return node('nan_type', {'value': token.text, 'pos': self._position(token)})
        if token.text == 'infinite':
            return node('infinite_type', {'value': token.text, 'pos': self._position(token)})
        if token.text.startswith('"') and token.text.endswith('"'):
            return node('string', {'value': token.text, 'pos': self._position(token)})
        if token.text.startswith("'") and token.text.endswith("'"):
            return node('number', {'value': token.text, 'pos': self._position(token)})
        if token.text.startswith('`') and token.text.endswith('`'):
            return node('address', {'value': token.text, 'pos': self._position(token)})
        # 纯数字（不带引号）应被识别为整数字面量 `integer`
        if token.text.isdigit():
            return node('integer', {'value': token.text, 'pos': self._position(token)})
        if token.text == 'in':
            return node('name', {'value': token.text, 'pos': self._position(token)})
        if token.text.startswith('#') and token.text.endswith('#'):
            return node('comment', {'value': token.text, 'pos': self._position(token)})
        if token.text.isidentifier():
            # 按语法要求，name 不能包含数字
            if any(ch.isdigit() for ch in token.text):
                self.raise_error(f'标识符不可包含数字: {token.text}', token)
            return node('name', {'value': token.text, 'pos': self._position(token)})
        self.raise_error(f'无法解析词元: {token.text}', token)

    def get_precedence(self, token: str) -> Optional[int]:
        if token == 'in':
            return self.BINARY_PRECEDENCE.get('in')
        return self.BINARY_PRECEDENCE.get(token)


def code_to_json(path):
    def process_path_improved(original_path: str) -> str:
        # 使用 os.path.splitext 分离文件扩展名
        name_without_ext, ext = os.path.splitext(original_path)
        # 如果是 .tsuc 文件，使用 .tscc 作为新扩展名
        if ext.lower() != '.tsuc':
            # 如果不是 .tsuc 文件，给出建议但仍输出结果
            warning(
                [
                    '输入文件不是 .tsuc 后缀',
                    f'输入文件为 {name_without_ext + ext}'
                ]
            )
        return name_without_ext + '.tscc'

    if not os.path.exists(path):
        error([f'路径 {path} 不存在'])
    with open(path, 'r', encoding = 'utf-8') as file:
        content = file.read()
        path = process_path_improved(path)
        tokenizer = lexer()
        tokens = tokenizer.parse_to_tokens(content)
        parse = parser(tokens)
        return_list = parse.to_json()
        return_value = {'Tanex Script': return_list}
        with open(path, 'w', encoding = 'utf-8') as file:
            file.write(
                json.dumps(
                    return_value,
                    indent = 4,
                    ensure_ascii = False
                )
            )
        return return_value

__all__ = ['code_to_json']
